package compiladorassemble;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

/*
        ATENÇÃO TODAS AS CLASSES QUE POSSUEM: throws IOException TEM ESCRITA DE INFORMAÇÕES EM ARQUIVOS, POR ISSO O 
THROWS PARA FAZER O TRATAMENTO DE ERROS NA PROPRIA CLASSE AO INVES DE USAR VARIOS TRY CATCHS
        EXISTEM DOIS ARQUIVOS:

        *LOG: que cria tecnicamente um arquivo de log, com todas as informações de como foi tratada as expressoes
mostrando os valores no acumulador AC e nas suas variaveis.

        *ARQUIVO: cria um arquivo totalmente referente ao programa que fi traduzido para assembler desde suas primeiras
instruções, resolução da equação e a finalização do programa.
 */
public class Metodos extends Compilador{

    private FileWriter log, arquivo;
    private int u = 0, v = 0, w = 0, x = 0, y = 0, z = 0;
    private Compilador comp = new Compilador();
   
    public void Processamento(String expressao) throws IOException{
        

        /* TRATAMENTO DO CONTEUDO RECEBIDO DENTRO DA VARIAVEL STRING */
        expressao = expressao.trim();       //remove espaços em branco do inico e do final da String
        expressao = expressao.toUpperCase(); //Deixar a expressao em letras maiusculas                                    

        int parenF = 0, parenA = 0; //cria duas variaveis para a verificação dos parenteses
        boolean verifica = false; //essa variavel serve para saber se tem numeros na expressao

        for (int i = 0; i < expressao.length(); i++) {        // percorre a expresso

            if (Character.isDigit(expressao.charAt(i)) == true) // valida se tem numeros
            {
                verifica = true;
            }
            if (expressao.charAt(i) == '(') //verifica quantos parenteses tem abertos
            {
                parenA++;
            } else if (expressao.charAt(i) == ')') {//verifica quantos parenteses tem fecados
                parenF++;
            }
        }

        if (parenA != parenF || verifica == true) {
            JOptionPane.showMessageDialog(null, "Sintaxe da expressão incorreta\nTente novamente", "Erro", 2);
            System.exit(0);
        } else {
            String endereco = Criartxt();
            log.write("Expressão:" + expressao + "\r\n");
            CarregaInicio();
            do {
                parenA = 0; //zera parenteses aberto
                parenF = expressao.indexOf(")");        //pega o primeiro parenteses fechado
                String quebra = "";         //quebra igual vaziorr
                for (int i = expressao.indexOf("("); i < parenF; i++) { //verifica se dentro dessa expressão ainda tem outro parenteses aberto
                    if (expressao.charAt(i) == '(') {                     // a variavel i = 0 primeiro parenteses aberto.
                        parenA = i;
                    }
                }
                if (parenF == 0) {                                        // se a expressao não tiver parenteses dentro de parentes
                    parenA = expressao.indexOf("(");                    // então ele informa que o primeiro parenteses aberto é o certo
                }

                if (parenF < 0) { // se parenA for igual a 0 então a expressão não esta entre parenteses
                    /* adiciona '(' no começo e o ')' no final da String NA VARIAVEL QUEBRA porque quando acontece a quebra 
                    ele procura juntamente com o grupo de parenteses, quando essa quebra ele entra na função resolve ele tira esses parentes, 
                    se não tive essa inclussão nas duas variavei o programa entra em loop infinito*/
                    //quebra = "(" + expressao + ")";
                    expressao = "(" + expressao + ")";
                    quebra = expressao;
                } else {
                    quebra = expressao.substring(parenA, parenF + 1);//quebra a parte do parenteses da string
                }

                String aux = Resolve(quebra);  //passa a expressão

                expressao = expressao.replace(quebra, aux); //retira da expressao o que foi quebrado e substitui pelo retorno resolvida
                log.write("Expressão:" + expressao + "\r\n");
            } while (expressao.length() != 1);
            CarregarFinal();
            AbrirArquivo(endereco);
            FecharAquivo();
        }

    }

    private String Resolve(String aux) throws IOException {
        boolean divMult = false;
        //RETIRA O PARENTESESDO INICIO
        aux = aux.substring(1, aux.length() - 1); //retira o parentses do começo e final
        String quebras = "";
        String novaExp = aux;

        for (int i = 1; i < aux.length(); i++) {
            if (aux.charAt(i) == '*' || aux.charAt(i) == '/') {
                String op1 = "" + aux.charAt(i - 1), op2 = aux.charAt(i + 1) + ""; //pega as letras antes e depois do sinal
                quebras = op1 + aux.charAt(i) + op2; //concatena elas juntamente com o sinal e adciona em quebras
                quebras = quebras.trim(); //retira os espaços do começo e final da expressão
                Load(aux.charAt(i - 1));//chama o metodo loade que move o primeiro para a memória
                divMult = true; //coloca true na varial divMulti informando que existe divisão sim
                i = aux.length(); //coloca o tamanho de aux no i para sair do laço na primeira vez que acha um desses sinais
            }
        }

        if (quebras.equalsIgnoreCase("")) {
            Load(aux.charAt(0));//chama o metodo loade que move o primeiro para a memória
        }

        //System.out.println("Tamanho:" + aux.length());
        if (aux.length() != 1) {  // acontece casos que é passa para o metodo string um conteudo por exemplo assim (U) nesse caso quando é retirado os parenteses o conteudo fica so U, esse if serve para retornar esse conteudo Já que não é necessário efetuar nenhuma resolução.

            if (aux.length() > 3 && divMult != true) {
                quebras = aux.substring(0, 3);
            } else if (aux.length() <= 3 && divMult != true) {
                quebras = aux;
                //System.out.println("Quebra aux<=3 sem */:" + quebras);
            }

            switch (quebras.charAt(1)) {
                case '+':   //caso seja adição entra aqui
                    Add(quebras);
                    break;

                case '-'://caso seja subtração entra aqui
                    Sub(quebras);
                    break;

                case '*'://caso seja multilicação entra aqui
                    Mpy(quebras);
                    break;

                case '/'://caso seja divisão entra aqui
                    Div(quebras);
                    break;
            }
        }
        aux = Story(quebras); //chama o metodo Story que retorna a letra da varial que sera armazenado a resolução
        novaExp = novaExp.replace(quebras, aux); // faz a retirada do que tem na variavel quebras e coloca o retorno que está em aux
      
        if (novaExp.length() != 1) { //se  expressão for diferente de 1 significa ela sera a proxima expressão que tem que ser resolvida
            novaExp = "(" + novaExp + ")"; //para que isso acontece nos colocamos um grupo de parenteses entre ela e retorna ela com os parentes para ser proxima a enterar nesse metodo
        }
        return novaExp;
    }

    private void Load(char op1) throws IOException {
        log.write("LOAD " + op1 + "\r\t AC = " + op1 + "\r\n");
        arquivo.write("LOAD " + op1 + "\r\n");
    }

    private String Story(String aux) throws IOException {
        //variaveis para colocar o que tem dentro da memoria
        String zerarVar = aux;
        if (u == 0) {
            aux = "U";
            u = 1;
        } else if (v == 0) {
            aux = "V";
            v = 1;
        } else if (w == 0) {
            aux = "W";
            w = 1;
        } else if (x == 0) {
            aux = "X";
            x = 1;
        } else if (y == 0) {
            aux = "Y";
            y = 1;
        } else if (z == 0) {
            aux = "Z";
            z = 1;
        }

        for (int i = 0; i < zerarVar.length(); i++) {
            ZerarVar(zerarVar.charAt(i));
        }

        log.write("STORY " + aux + "  " + aux + "=AC" + "\r\n");
        arquivo.write("STORY " + aux + "\r\n");
        return aux;
    }

    private void ZerarVar(char letra) {
        switch (letra) {

            case 'U':
                u = 0;
                break;
            case 'V':
                v = 0;
                break;
            case 'W':
                w = 0;
                break;
            case 'X':
                x = 0;
                break;
            case 'Y':
                y = 0;
                break;
            case 'Z':
                z = 0;
                break;
        }
    }

    private void Add(String aux) throws IOException {
        char op2 = aux.charAt(2);
        log.write("ADD " + op2 + "\r\t AC = AC+" + op2 + "\r\n");
        arquivo.write("ADD " + op2 + "\r\n");
    }

    private void Sub(String aux) throws IOException {
        char op2 = aux.charAt(2);
        log.write("SUB " + op2 + "\r\t AC = AC-" + op2 + "\r\n");
        arquivo.write("SUB " + op2 + "\r\n");
    }

    private void Mpy(String aux) throws IOException {
        char op2 = aux.charAt(2);
        log.write("MPY " + op2 + "\r\t AC = AC*" + op2 + "\r\n");
        arquivo.write("MPY " + op2 + "\r\n");
    }

    private void Div(String aux) throws IOException {
        char op2 = aux.charAt(2);
        log.write("DIV " + op2 + "\r\t AC = AC/" + op2 + "\r\n");
        arquivo.write("DIV " + op2 + "\r\n");
    }

    private void CarregaInicio() throws IOException {
        arquivo.write("TITLE : COMPILADOR ASSEMBLER\r\n");
        arquivo.write(".MODEL SMALL\r\n");
        arquivo.write(".STACK 100H\r\n");
        arquivo.write(".CODE\r\n");
        arquivo.write("MAIN PROC\r\n");
    }

    private void CarregarFinal() throws IOException {
        arquivo.write("MOV AH,4CH\r\n");
        arquivo.write("INT 21H\r\n");
        arquivo.write("MAIN ENDP\r\n");
        arquivo.write("END MAIN\r\n");
    }

    private String Criartxt() throws IOException {

        JFileChooser fc = new JFileChooser(System.getProperty("user.dir")); //criar um JFileChooser para escolha de arquivo e informa ao sistema que vai trabalhar com diretorio
        String endereco = "", nome = ""; // cria as variavel nome e endereco
        FileFilter filter = new javax.swing.filechooser.FileFilter() { //cria um filtro
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt"); // retorna o diretorio ou o nome em minusculo com o .txt no final
            }

            public String getDescription() {
                return "(*.txt)"; //caso o usario queira filtrar pelo txt
            }
        };
        fc.addChoosableFileFilter(filter);
        int returnVal = fc.showDialog(null, "Salvar"); //pega o valor do botão pra saber qual botão foi clicado

        if (returnVal == JFileChooser.APPROVE_OPTION) {
            //como ele clicou em salvar acontecera isso:
            endereco = fc.getSelectedFile().getAbsolutePath(); // pega o endereço do arquivo que vai ser contido o resultado da expressao
            nome = fc.getSelectedFile().getName(); //pega o nome do arquivo para dps colocar a palavra log na frente e criar o arquivo de log naquela expressao
        } else if (returnVal == JFileChooser.CANCEL_OPTION) {
            //caso o usuario clique em cancelar acontece isso
        } else if (returnVal == JFileChooser.UNDEFINED_CONDITION) {
            
        }

        arquivo = new FileWriter(endereco); //cria um aquivo txt
        String enderecoLog = endereco.replace(nome, "log" + nome);  // o nome do arquivo rece a palavra log na frente
        log = new FileWriter(enderecoLog); //cria um aquivo txt
        return endereco;
    }

    private void FecharAquivo() {
        try {
            log.close();             //fecha o aquivo txt
            arquivo.close();
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
    }
    
    private void AbrirArquivo(String Endereco) { //essa classe erve para abrir o arquivo assim que comiplar
        Process pro; // cria uma variavel pro informando que ela se refe a processamentos
        try {
            pro = Runtime.getRuntime().exec("cmd.exe /c  "+Endereco); //informa que o programa devera abrir o arquivo da variavel endereço
        } catch (IOException ex) {
            Logger.getLogger(Metodos.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
}
